// Runs a full CRUD demo against the real Student API and prints the results.
// Usage:  node demo.js
import express from 'express';
import mongoose from 'mongoose';
import studentRoutes from './routes/studentRoutes.js';

const LOCAL_URI = 'mongodb://127.0.0.1:27017/student_records';
let memoryServer = null;

async function connect() {
  try {
    await mongoose.connect(LOCAL_URI, { serverSelectionTimeoutMS: 3000 });
    console.log('Connected to local MongoDB (127.0.0.1:27017)');
  } catch {
    console.log('Local MongoDB not running -> starting temporary in-memory MongoDB...');
    console.log('(first time it downloads MongoDB, please wait a few minutes)');
    const { MongoMemoryServer } = await import('mongodb-memory-server');
    memoryServer = await MongoMemoryServer.create();
    await mongoose.connect(memoryServer.getUri('student_records'));
    console.log('Connected to in-memory MongoDB');
  }
}

const show = (students) =>
  console.table(
    [].concat(students).map((s) => ({
      id: String(s._id),
      name: s.name,
      age: s.age,
      course: s.course,
      email: s.email,
    }))
  );

async function main() {
  await connect();

  const app = express();
  app.use(express.json());
  app.use('/students', studentRoutes);
  const server = app.listen(0);
  const base = `http://127.0.0.1:${server.address().port}/students`;

  const call = async (method, url, body) => {
    const res = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined,
    });
    const data = await res.json();
    console.log(`\n>>> ${method} ${url.replace(base, '/students')}  ->  ${res.status}`);
    return data;
  };

  const Student = (await import('./models/Student.js')).default;
  await Student.deleteMany({}); // start clean so output is the same every run

  console.log('\n========== STUDENT RECORDS API : CRUD DEMO ==========');

  // CREATE
  console.log('\n[CREATE] Adding 3 students (POST)');
  const a = await call('POST', base, { name: 'Ravi Kumar', age: 20, course: 'B.Tech CSE', email: 'ravi@example.com' });
  console.log(a.message);
  const b = await call('POST', base, { name: 'Anita Sharma', age: 21, course: 'B.Tech IT', email: 'anita@example.com' });
  console.log(b.message);
  const c = await call('POST', base, { name: 'John David', age: 23, course: 'MCA', email: 'john@example.com' });
  console.log(c.message);

  // READ ALL
  console.log('\n[READ] Get all students (GET)');
  show(await call('GET', base));

  // READ ONE
  console.log(`\n[READ] Get one student by id (GET)`);
  show(await call('GET', `${base}/${c.student._id}`));

  // UPDATE
  console.log('\n[UPDATE] Change John David\'s course to MBA (PATCH)');
  const upd = await call('PATCH', `${base}/${c.student._id}`, { course: 'MBA' });
  console.log(upd.message);
  show(await call('GET', base));

  // VALIDATION ERROR
  console.log('\n[VALIDATION] Adding student with age 10 (min is 16)');
  const bad = await call('POST', base, { name: 'Kid', age: 10, course: 'X', email: 'kid@example.com' });
  console.log(bad.message, '-', bad.error);

  // DELETE
  console.log('\n[DELETE] Remove John David (DELETE)');
  const del = await call('DELETE', `${base}/${c.student._id}`);
  console.log(del.message);
  show(await call('GET', base));

  console.log(`\nTotal students in DB: ${await Student.countDocuments()}`);
  console.log('====================================================\n');

  server.close();
  await mongoose.disconnect();
  if (memoryServer) await memoryServer.stop();
}

main().catch(async (err) => {
  console.error('\nDemo failed:', err.message);
  process.exit(1);
});
