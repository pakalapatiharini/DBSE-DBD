@echo off
REM Installs packages (first time only) and runs the CRUD demo.
set DEST=C:\CO4_run
if exist "%DEST%" rmdir /s /q "%DEST%"
xcopy "%~dp0*" "%DEST%\" /E /I /Q /Y >nul
cd /d "%DEST%"
call npm install
node demo.js
pause
